from django.shortcuts import render
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import numpy as np
import xgboost as xgb


def home(request):
    return render(request, "home.html")


def predict(request):
    return render(request, "predict.html")


def binary_transformation(y):
    for x in range(len(y)):
        if y[x] == 'User':
            y[x] = 1
        else:
            y[x] = 0
    return y.astype('int')


def result(request):
    path = 'https://archive.ics.uci.edu/ml/machine-learning-databases/00373/drug_consumption.data'
    title = ['ID', 'Age', 'Gender', 'Education', 'Country', 'Ethnicity', 'Nscore', 'Escore', 'Oscore', 'Ascore',
             'Cscore', 'Impulsive', 'SS', 'Alchool', 'Amphet', ' Amyl', 'Benzos', 'Caff', 'Canabis', 'Choc', 'Coke',
             'Crack', 'Extasy', 'Heroin', 'Ketamine', 'Leghal', 'LSD', 'Meth', 'Mushrooms', 'Nicotine', 'sumer', 'VSA']
    drug_consumption = pd.read_csv(path, sep=',', names=title)
    drug_consumption.drop('ID', axis=1, inplace=True)
    demographic_columns = ['Age', 'Gender', 'Education', 'Country', 'Ethnicity']
    personality_columns = ['Nscore', 'Escore', 'Oscore', 'Ascore', 'Cscore', 'Impulsive', 'SS']
    feature_columns = demographic_columns + personality_columns
    drugs_columns = ['Alchool', 'Amphet', ' Amyl', 'Benzos', 'Caff', 'Canabis', 'Choc', 'Coke', 'Crack', 'Extasy',
                     'Heroin', 'Ketamine', 'Leghal', 'LSD', 'Meth', 'Mushrooms', 'Nicotine', 'sumer', 'VSA']
    drugs_legal = ['Alchool', 'Caff', 'Choc', 'Nicotine']
    drugs_illegal = list(set(drugs_columns) - set(drugs_legal))
    user_dictionary = {
        'CL6': 'User',
        'CL5': 'User',
        'CL4': 'User',
        'CL3': 'User',
        'CL2': 'Non-user',
        'CL1': 'Non-user',
        'CL0': 'Non-user',
    }
    drug_consumption['Illegal drug use'] = drug_consumption[drugs_illegal].max(axis=1)
    drug_consumption['Illegal drug user/non-user'] = list(
        map(lambda x: user_dictionary[x], drug_consumption['Illegal drug use']))
    for i in drugs_columns:
        drug_consumption[i] = drug_consumption[i].map(
            {'CL0': 0, 'CL1': 1, 'CL2': 2, 'CL3': 3, 'CL4': 4, 'CL5': 5, 'CL6': 6})
    drug_consumption['Illegal drug use'] = drug_consumption['Illegal drug use'].map(
        {'CL0': 0, 'CL1': 1, 'CL2': 2, 'CL3': 3, 'CL4': 4, 'CL5': 5, 'CL6': 6})
    drug_consumption_ml = drug_consumption.copy()
    drug_consumption_ml.drop(drugs_illegal, axis=1, inplace=True)
    x = drug_consumption_ml.iloc[:, :-2]
    y = drug_consumption_ml['Illegal drug user/non-user']
    y = binary_transformation(y)

    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.33)
    scaler = StandardScaler()
    scaler.fit(x_train)
    x_train = scaler.transform(x_train)

    age = float(request.GET['age'])
    gender = float(request.GET['gender'])
    education = float(request.GET['education'])
    country = float(request.GET['country'])
    ethnicity = float(request.GET['ethnicity'])

    nscore = float(request.GET['nscore'])
    escore = float(request.GET['escore'])
    oscore = float(request.GET['oscore'])
    ascore = float(request.GET['ascore'])
    cscore = float(request.GET['cscore'])

    impulsive = float(request.GET['impulsive'])
    ss = float(request.GET['ss'])

    alcohol = int(request.GET['alcohol'])
    caff = int(request.GET['caff'])
    choc = int(request.GET['choc'])
    nicotine = int(request.GET['nicotine'])

    data = np.array([age, gender, education, country, ethnicity,
                     nscore, escore, oscore, ascore, cscore,
                     impulsive, ss, alcohol, caff, choc, nicotine]).reshape(1, -1)

    scaler.transform(data)

    xg_reg = xgb.XGBClassifier(objective='binary:hinge', colsample_bytree=0.7, learning_rate=0.012, subsample=0.8,
                               n_estimators=250)
    xg_reg.fit(x_train, y_train.astype(object))
    pred = xg_reg.predict(data)

    drug_user = ""
    if pred[0] == 1:
        drug_user = "The person corresponding to those values is predicted to be an illegal drugs user by the " \
                    "Gaussian Algorithm. "
    else:
        drug_user = "The person corresponding to those values is predicted NOT to be an illegal drugs user by the " \
                    "Gaussian Algorithm. "

    return render(request, "prediction.html", {"result": drug_user})
